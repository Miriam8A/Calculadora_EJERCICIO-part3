using System;

namespace CONTACTO_EJERCICIO.Models{
    public class Calculadora{
        public Double Operador1{get;set;}
        public Double Operador2{get;set;}
        public string Operando{get;set;}
    }
}
